import "./DashboardLogin.scss";

export default function DashboardLogin() {
  return (
    <div className="container login-greeting">
      <h1 className="title">
        Welcome! <br /> Please enter your first and last name to register
      </h1>
    </div>
  );
}
